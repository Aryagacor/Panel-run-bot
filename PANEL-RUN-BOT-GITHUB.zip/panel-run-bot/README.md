# PANEL RUN BOT | BY ARYA PRADIFTA

GitHub-ready Android WebView project. The current APK build contains the anime login screen and red-neon control-panel UI.

## Build APK with GitHub only
1. Create a GitHub repository named `PANEL-RUN-BOT`.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. Open **Actions** and run **Build PANEL RUN BOT APK**, or push to `main`.
4. Download `PANEL-RUN-BOT-debug-apk` from the completed workflow run's Artifacts section.

## Current implementation status
- Anime login background uses `app/src/main/assets/anime-profile.jpg`.
- Red-neon dashboard and developer credit are included.
- Android APK packaging workflow is included.
- Bot engine, WhatsApp authentication/QR pairing, persistent session storage, and background runtime are **not implemented yet**. The current Start/Stop/Pair buttons are UI placeholders and do not connect to WhatsApp.

A real no-VPS implementation needs an Android-compatible Node.js runtime or a native Android bot engine, plus a maintained WhatsApp Web integration and lifecycle/session handling. GitHub Actions builds the APK; it does not host the bot.
